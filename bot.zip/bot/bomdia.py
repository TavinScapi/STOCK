import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import schedule
import time

# Lista de destinatários
destinatarios = [
    'raissa.noda@aluno.senai.br',
    'otavio.scapi@aluno.senai.br',
    'maria.pereira55@aluno.senai.br',
    'pedrohenriquealves@aluno.senai.br',
    'barbaraalvarenga304@gmail.com',
    'nathalia.cazonato@aluno.senai.br',
]

# Função para enviar e-mail
def enviar_email(mensagem, assunto, imagem_url=None):
    try:
        # Configurações do e-mail
        remetente = 'estoquestockstore@gmail.com'
        senha = 'hcry egss zzbb izik'

        # Configurar o servidor SMTP do Gmail
        servidor = smtplib.SMTP('smtp.gmail.com', 587)
        servidor.starttls()  # Inicia a criptografia TLS
        servidor.login(remetente, senha)

        for destinatario in destinatarios:
            # Compor o e-mail com HTML e imagem
            corpo_html = f"""
            <html>
              <body>
                <p>Olá {destinatario.split('@')[0]},</p>
                <p>{mensagem}</p>
            """
            if imagem_url:
                corpo_html += f'<p><img src="{imagem_url}" alt="Mensagem do dia" style="width:300px;"></p>'
            corpo_html += """
                <p>Com atenção,<br>Zé da Recaida.</p>
              </body>
            </html>
            """

            # Configurar o e-mail
            msg = MIMEMultipart()
            msg['From'] = remetente
            msg['To'] = destinatario
            msg['Subject'] = assunto
            msg.attach(MIMEText(corpo_html, 'html'))

            # Enviar o e-mail
            servidor.sendmail(remetente, destinatario, msg.as_string())
            print(f"E-mail enviado com sucesso para {destinatario}!")

        servidor.quit()

    except Exception as e:
        # Registrar erros
        print(f"Erro ao enviar e-mail: {e}")

# Mensagens
def mensagem_bom_dia():
    mensagem = "🌅 Bom dia! Desejamos a você um dia repleto de conquistas e bons momentos. 😊"
    imagem_url = "https://lh5.googleusercontent.com/proxy/TRMSeKDedzCmCyOuvYMMaiXSOMXSrzMCD7JI78IgZ-QvJ-dnYCAVBX955_PgxnKklyg6yDniyz63dWLS6VbyI2roL1e5lCp3sApEt0viPPr-8C0tOomFit3ohA"  # Substitua com a URL de sua imagem
    enviar_email(mensagem, "🌅 Bom Dia!", imagem_url)

def mensagem_cafe_da_manha():
    mensagem = "☕ Bom café da manhã! Aproveite esse momento para se energizar com um bom café e começar o dia com disposição. 🥐"
    imagem_url = "https://lh3.googleusercontent.com/proxy/kCGs6x4Hw2c-Ol2Y1OvauISGFdi5ntvSRGchh8oOUmuSD-IcKaBgQ2OTVJFgu1F9B3QIvJZYl_cH1GB6IZP0A7qO7nF26bRG4lDu2ZAAm34O8M4sXMVZfisXRA"  # Substitua com a URL de sua imagem
    enviar_email(mensagem, "☕ Bom Café da Manhã!", imagem_url)

def mensagem_bom_almoco():
    mensagem = "🍴 Bom almoço! Aproveite essa pausa para recarregar suas energias e se preparar para o restante do dia. 😋"
    imagem_url = "https://chat.google.com/u/0/api/get_attachment_url?url_type=FIFE_URL&content_type=image%2Fpng&attachment_token=AOo0EEWYUklxpTHygTiZB%2BJFKn18sKPXetippGrLJjaOJnUJJXF%2BjMj89tVehsXN%2Bo698XbwoFHVg5wqt2%2FFQzOrxLXEbAnGnvOAmJzkjZXvfV2YErO2Gv2vgjofn9kTAE2g3JLnw3zKnD3IkXnxzoNaOW7CwaEaVooLTtx4E6FuSoEm5%2BeMOc6XZQLoUfXU6MNYJRU0irOwWaaPQmL5D08poVv7MnJC2r002LM6hd7xQ1txTZjw1CggJd9%2BDB74BgB85V675USfBAyNP2eDbupzf6UWlRa5%2BhjjYQmQOZuXcyQu1W%2FW3Eg0K8P7vWrCY6ruhDKCqvTF7u7Z9ECGCXK4%2B%2FUvpON8P6bNqEIUmjSE6NZqIZrEXMbARSHJrwtBomyOgrbfVEh2gfWDxSUebzE5%2BGw2RUCO4lnG%2F05eqIfkNHc2bYXdVfjqdhJgcj0AiyFOWo9CsgGJZecl%2BjwRN%2BZ4%2FcS1nZreqV55Skztm3PaZkE8gA0emkZ3Z%2FiSBxfaPFav7QKEp1yKTswV%2FBtcqGt1SL9HgEFzIeem7OkzLthCJ48VfB0XfmqZ5rap8x7kDwm8fQ%3D%3D&sz=w512"  # Substitua com a URL de sua imagem
    enviar_email(mensagem, "🍴 Bom Almoço!", imagem_url)

def mensagem_cafe_da_tarde():
    mensagem = """
    ☕🍪 Bom café da tarde! 🌞
    A tarde chegou e é hora de fazer uma pausa deliciosa! Aproveite para relaxar e saborear um bom café acompanhado de algo doce.
    Não se esqueça de tirar um tempo para você e se energizar para o que vem pela frente!
    """
    imagem_url = "https://chat.google.com/u/0/api/get_attachment_url?url_type=FIFE_URL&content_type=image%2Fpng&attachment_token=AOo0EEWmwezSfIVcmz32R6z0FeENUEy4qumlCtpf8O7gTPtwNncfDUR2Oo1lpasmTNgPzeG%2FKIPf8zZTFHbCNPC3yGSH%2B6zkWnG8kMoNUxclmtehC0yGE6uFPN8qCYe%2FNonEobwnJvQOFS3kaCtPWJt%2ByQo6nBXxI1kPwvyNVFRA%2BLJQYBMeuhDxtvq5Qt32xt1M9ydebF27DilCQwhHyxUi67K2%2BbU2MIF586%2F1Xo7gczxaqPMagE9afrG1ZNhqKBLKqzZWNUhIuJXKBBt%2BASWoLSJMORY5Mzzk%2FP7guTA03VqEjQQ2HHmdgfV%2BbGhO7bpqDhahJzpf4vFrmeF%2B1jW%2BWvDBN87y2Nn0jaVidirGhOn6BKhxbZVwi%2FCm1w9lUI0nKz2CYQZUWfmV7birQ2uvi9m4lyIm7dYq5tNlSEVJVh8P%2FNf7NMOKhu82SSxT8PW6bfQQ6VkF8URPh%2FAKoWbyiES5DNXDP%2BUyhqz2Q3yu8zGBe0KJcHL5AxhzAMVcs%2B02NVzgf5ebJngoFQM%2FmVP5tZElIVcSQ1BJB9S1Pdc8l4peQOupGJoatb%2FMk2x12NfS&sz=w512"  # Substitua com a URL de sua imagem
    enviar_email(mensagem, "🍪 Bom Café da Tarde!", imagem_url)

def mensagem_boa_tarde_despedida():
    mensagem = "🌇 Boa tarde! O dia está quase acabando, parabéns por tudo o que foi feito. Agora é hora de encerrar e descansar. 👏"
    imagem_url = "https://lh6.googleusercontent.com/proxy/etz2BOvR6PaHVhWV9OzIXrgQuD5RagVqMkVt-veGojJxg6BZa9D4cLb9LAwXdu-5X9zmI0piWwtO22CCTJ6RnJo1MoYwbENkov2VySs5Uvc0JTP_gjaDIb2vhA"  # Substitua com a URL de sua imagem
    enviar_email(mensagem, "🌇 Boa Tarde e Despedida", imagem_url)

# Agendar os envios
schedule.every().day.at("07:40").do(mensagem_bom_dia)  # Enviar às 07:40
schedule.every().day.at("09:45").do(mensagem_cafe_da_manha)  # Enviar às 09:45
schedule.every().day.at("11:30").do(mensagem_bom_almoco)  # Enviar às 11:30
schedule.every().day.at("14:45").do(mensagem_cafe_da_tarde)  # Enviar às 14:45
schedule.every().day.at("16:45").do(mensagem_boa_tarde_despedida)  # Enviar às 16:45

print("Agendamento iniciado. Os e-mails serão enviados nos horários definidos.\nPressione Ctrl+C para parar o programa.")

# Rodar o agendamento indefinidamente
while True:
    try:
        schedule.run_pending()  # Executa as tarefas agendadas
        time.sleep(1)  # Espera 1 segundo antes de verificar novamente
    except KeyboardInterrupt:
        print("\nPrograma interrompido pelo usuário. Encerrando...")
        break