import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import schedule
import time

# Lista de destinatários
destinatarios = [
    'raissa.noda@aluno.senai.br',
    'otavio.scapi@aluno.senai.br',
    'maria.pereira55@aluno.senai.br',
    'pedrohenriquealves@aluno.senai.br',
    'barbaraalvarenga304@gmail.com',
    'nathalia.cazonato@aluno.senai.br',
]

# Função para enviar e-mail
def enviar_email(mensagem, assunto, imagem_url=None, opt_out=False):
    try:
        # Configurações do e-mail
        remetente = 'estoquestockstore@gmail.com'
        senha = 'hcry egss zzbb izik'

        # Configurar o servidor SMTP do Gmail
        servidor = smtplib.SMTP('smtp.gmail.com', 587)
        servidor.starttls()  # Inicia a criptografia TLS
        servidor.login(remetente, senha)

        for destinatario in destinatarios:
            # Adiciona a opção de opt-out (desinscrição) no final da mensagem
            if opt_out:
                mensagem += f"""
                <p><strong>Você deseja continuar recebendo e-mails da Stock.Store?</strong><br>
                Se não deseja mais receber nossas mensagens, clique aqui para <a href="mailto:{remetente}?subject=Opt-out%20Stock.Store&body=Não%20desejo%20mais%20receber%20e-mails">cancelar a inscrição</a>.</p>
                """

            # Compor o e-mail com HTML e imagem
            corpo_html = f"""
            <html>
              <body>
                <p>Olá {destinatario.split('@')[0]},</p>
                <p>{mensagem}</p>
            """
            if imagem_url:
                corpo_html += f'<p><img src="{imagem_url}" alt="Mensagem do dia" style="width:300px;"></p>'
            corpo_html += """
                <p>Atenciosamente,<br>Equipe Stock.Store</p>
              </body>
            </html>
            """

            # Configurar o e-mail
            msg = MIMEMultipart()
            msg['From'] = remetente
            msg['To'] = destinatario
            msg['Subject'] = assunto
            msg.attach(MIMEText(corpo_html, 'html'))

            # Enviar o e-mail
            servidor.sendmail(remetente, destinatario, msg.as_string())
            print(f"E-mail enviado com sucesso para {destinatario}!")

        servidor.quit()

    except Exception as e:
        # Registrar erros
        print(f"Erro ao enviar e-mail: {e}")

# Mensagens
def mensagem_bom_dia():
    mensagem = "🌅 Bom dia, colaborador! Comece o dia com organização e eficiência. Lembre-se de que um bom gerenciamento de estoque é essencial para o sucesso da Stock.Store. 💼"
    imagem_url = "https://www.example.com/bom-dia.jpg"  # Substitua com a URL de sua imagem
    enviar_email(mensagem, "🌅 Bom Dia, Stock.Store!", imagem_url, opt_out=True)

def mensagem_cafe_da_manha():
    mensagem = "☕ Bom café da manhã! Aproveite este momento para se energizar e organizar as tarefas do dia. Um estoque bem administrado começa com uma boa preparação. 🥐"
    imagem_url = "https://www.example.com/cafe-da-manha.jpg"  # Substitua com a URL de sua imagem
    enviar_email(mensagem, "☕ Bom Café da Manhã, Stock.Store!", imagem_url, opt_out=True)

def mensagem_bom_almoco():
    mensagem = "🍴 Bom almoço! É hora de recarregar as energias e revisar as ordens de estoque. Uma pausa bem feita ajuda a manter a produtividade. 😋"
    imagem_url = "https://www.example.com/bom-almoco.jpg"  # Substitua com a URL de sua imagem
    enviar_email(mensagem, "🍴 Bom Almoço, Stock.Store!", imagem_url, opt_out=True)

def mensagem_cafe_da_tarde():
    mensagem = """
    ☕🍪 Bom café da tarde! 🌞
    É hora de relaxar um pouco e revisar o inventário. Um bom descanso é necessário para continuar garantindo a eficiência da nossa gestão de estoque!
    Aproveite este tempo para ajustar os detalhes e manter tudo organizado.
    """
    imagem_url = "https://www.example.com/cafe-da-tarde.jpg"  # Substitua com a URL de sua imagem
    enviar_email(mensagem, "🍪 Bom Café da Tarde, Stock.Store!", imagem_url, opt_out=True)

def mensagem_boa_tarde_despedida():
    mensagem = "🌇 Boa tarde! O expediente está chegando ao fim. Faça uma última checada no estoque e prepare-se para encerrar o dia com tudo organizado para o amanhã. 👏"
    imagem_url = "https://www.example.com/boa-tarde.jpg"  # Substitua com a URL de sua imagem
    enviar_email(mensagem, "🌇 Boa Tarde e Despedida, Stock.Store!", imagem_url, opt_out=True)

# Agendar os envios
schedule.every().day.at("11:12").do(mensagem_bom_dia)  # Enviar às 07:40
schedule.every().day.at("09:45").do(mensagem_cafe_da_manha)  # Enviar às 09:45
schedule.every().day.at("11:30").do(mensagem_bom_almoco)  # Enviar às 11:30
schedule.every().day.at("14:45").do(mensagem_cafe_da_tarde)  # Enviar às 14:45
schedule.every().day.at("16:45").do(mensagem_boa_tarde_despedida)  # Enviar às 16:45

print("Agendamento iniciado. Os e-mails serão enviados nos horários definidos.\nPressione Ctrl+C para parar o programa.")

# Rodar o agendamento indefinidamente
while True:
    try:
        schedule.run_pending()  # Executa as tarefas agendadas
        time.sleep(1)  # Espera 1 segundo antes de verificar novamente
    except KeyboardInterrupt:
        print("\nPrograma interrompido pelo usuário. Encerrando...")
        break
    