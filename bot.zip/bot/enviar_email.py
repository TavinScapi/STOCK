import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import schedule
import time

# Lista de destinatários
destinatarios = [
    'raissa.noda@aluno.senai.br',
    'otavio.scapi@aluno.senai.br',
    'maria.pereira55@aluno.senai.br',
    'pedrohenriquealves@aluno.senai.br',
    'barbaraalvarenga304@gmail.com',
    'nathalia.cazonato@aluno.senai.br',
]

# Função para enviar e-mail
def enviar_email():
    try:
        # Configurações do e-mail
        remetente = 'estoquestockstore@gmail.com'
        senha = 'hcry egss zzbb izik'

        # Configurar o servidor SMTP do Gmail
        servidor = smtplib.SMTP('smtp.gmail.com', 587)
        servidor.starttls()  # Inicia a criptografia TLS
        servidor.login(remetente, senha)

        for destinatario in destinatarios:
            # Compor o e-mail com HTML e imagem por link
            assunto = '⚠️ Atenção: Sai do celular agora!'
            corpo_html = f"""
            <html>
              <body>
                <p>Olá {destinatario.split('@')[0]},</p>
                <p>
                  <strong>⚠️ Esta é uma advertência séria! ⚠️</strong><br>
                  Passar muito tempo no celular pode prejudicar sua saúde física e mental. 
                  Lembre-se de fazer pausas, cuidar da postura e priorizar suas tarefas importantes.
                </p>
                <p>Desligue o celular agora e vá cuidar do que realmente importa!</p>
                <p>
                  <img src="https://lh6.googleusercontent.com/proxy/0I16f8kH0I6YsnBMXxBRpDaawIMJclP5ndv5XG8B7fwHOs_GwbRiFf3DyzYGF71LNot-vyI3RhFP2YyKiA7oLyQEEuGSyx3SlYSm7SY1qYNga1wkyRdoFFQddw" 
                       alt="Aviso importante" style="width:300px;">
                </p>
                <p>Com atenção,<br>Zé da Recaida.</p>
              </body>
            </html>
            """

            # Configurar o e-mail
            msg = MIMEMultipart()
            msg['From'] = remetente
            msg['To'] = destinatario
            msg['Subject'] = assunto
            msg.attach(MIMEText(corpo_html, 'html'))

            # Enviar o e-mail
            servidor.sendmail(remetente, destinatario, msg.as_string())
            print(f"E-mail enviado com sucesso para {destinatario}!")

        servidor.quit()

    except Exception as e:
        # Registrar erros
        print(f"Erro ao enviar e-mail: {e}")

# Agendar o envio do e-mail a cada minuto
schedule.every(1).seconds.do(enviar_email)

print("Agendamento iniciado. O e-mail será enviado a cada 10 segundos.\nPressione Ctrl+C para parar o programa.")

# Rodar o agendamento indefinidamente
while True:
    try:
        schedule.run_pending()  # Executa as tarefas agendadas
        time.sleep(1)  # Espera 1 segundo antes de verificar novamente
    except KeyboardInterrupt:
        print("\nPrograma interrompido pelo usuário. Encerrando...")
        break